"""
Central configuration for SafeFlight Map.
Edit this file or set environment variables to override.
"""
import os
import secrets

class Settings:
    # Server
    HOST: str = os.getenv("SFM_HOST", "127.0.0.1")
    PORT: int = int(os.getenv("SFM_PORT", "8742"))

    # Database – stored next to the exe / in the project root
    DB_PATH: str = os.getenv(
        "SFM_DB_PATH",
        os.path.join(os.path.expanduser("~"), "SafeFlightMap", "sfm.db")
    )

    # HMAC secret used to hash device identifiers before storage.
    # Auto-generated on first run and persisted in a sidecar file.
    _SECRET_FILE: str = os.path.join(os.path.expanduser("~"), "SafeFlightMap", ".hmac_secret")

    @property
    def HMAC_SECRET(self) -> str:
        os.makedirs(os.path.dirname(self._SECRET_FILE), exist_ok=True)
        if os.path.exists(self._SECRET_FILE):
            with open(self._SECRET_FILE) as f:
                return f.read().strip()
        secret = secrets.token_hex(32)
        with open(self._SECRET_FILE, "w") as f:
            f.write(secret)
        return secret

    # Scanning
    WIFI_GAP_TIMEOUT_S:  float = float(os.getenv("SFM_WIFI_GAP", "2.0"))
    BLE_GAP_TIMEOUT_S:   float = float(os.getenv("SFM_BLE_GAP",  "1.0"))
    HEAT_CELL_METERS:    float = float(os.getenv("SFM_CELL_M",   "100.0"))
    RSSI_FLOOR:          float = float(os.getenv("SFM_RSSI_FLOOR", "-95.0"))

    # Targets allowlist file
    TARGETS_FILE: str = os.getenv(
        "SFM_TARGETS_FILE",
        os.path.join(os.path.expanduser("~"), "SafeFlightMap", "targets.json")
    )

    # OUI labels
    OUI_FUN_WATCHER: str = "00:25:DF"   # shown in blue
    OUI_FUN_STOPPER: str = "B4:1E:52"   # shown in red, timestamps required

settings = Settings()
