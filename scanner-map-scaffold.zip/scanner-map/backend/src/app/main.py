"""
SafeFlight Map – FastAPI backend entry point.
"""
import sys
import os

# Ensure the package root is on sys.path when run directly
_HERE = os.path.dirname(os.path.abspath(__file__))
_SRC  = os.path.join(_HERE, "..", "..")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from app.db.database import init_db
from app.api import control, targets, heatmap, encounters, exports
from app.core.config import settings

app = FastAPI(title="SafeFlight Map", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# API routers
app.include_router(control.router,    prefix="/control",   tags=["control"])
app.include_router(targets.router,    prefix="/targets",   tags=["targets"])
app.include_router(heatmap.router,    prefix="/heatmap",   tags=["heatmap"])
app.include_router(encounters.router, prefix="/encounters", tags=["encounters"])
app.include_router(exports.router,    prefix="/export",    tags=["exports"])


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.1.0"}


@app.on_event("startup")
async def startup():
    init_db()


# ── Static frontend (bundled or dev) ──────────────────────────────────────────
def _frontend_dist() -> str:
    """Return path to frontend/dist, works in dev and PyInstaller bundle."""
    if getattr(sys, "frozen", False):
        # PyInstaller unpacks to sys._MEIPASS
        base = sys._MEIPASS  # type: ignore[attr-defined]
    else:
        base = os.path.join(_HERE, "..", "..", "..", "..", "frontend", "dist")
    return os.path.normpath(base + "/frontend/dist") if getattr(sys, "frozen", False) else os.path.normpath(base)


_dist = _frontend_dist()
if os.path.isdir(_dist):
    app.mount("/", StaticFiles(directory=_dist, html=True), name="static")
else:
    @app.get("/")
    def index():
        return {"message": "Frontend not built yet. Run: cd frontend && npm install && npm run build"}
