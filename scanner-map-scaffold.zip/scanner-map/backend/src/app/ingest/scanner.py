"""
Scanner state manager.

Milestone 1: runs a fake data generator so the UI can be developed
             without real hardware.

Milestone 4: swap _wifi_scan() and _ble_scan() for real adapters.
"""
import random
import threading
import time
from typing import Optional
from app.core.allowlist import build_allowlist
from app.core.config import settings
from app.processing.aggregator import ingest_observation, flush_all

_running = False
_thread: Optional[threading.Thread] = None

# Fake route: a ~2-mile highway stretch in Phoenix, AZ
_FAKE_ROUTE = [
    (33.4484,  -112.0740),
    (33.4490,  -112.0720),
    (33.4497,  -112.0700),
    (33.4504,  -112.0680),
    (33.4511,  -112.0660),
    (33.4518,  -112.0640),
    (33.4525,  -112.0620),
    (33.4532,  -112.0600),
]

def _fake_loop():
    """Generate synthetic observations for UI development."""
    allowlist = build_allowlist()
    if not allowlist:
        # Inject two synthetic keys for demo purposes
        from app.core.allowlist import hash_identifier
        demo_keys = {
            hash_identifier("00:25:DF:AA:BB:01"): {
                "label": "Fun-Watcher Demo",
                "source": "wifi",
                "oui_label": "Fun-Watcher",
                "color": "blue",
            },
            hash_identifier("B4:1E:52:CC:DD:01"): {
                "label": "Fun-Stopper Demo",
                "source": "ble",
                "oui_label": "Fun-Stopper",
                "color": "red",
            },
        }
    else:
        demo_keys = allowlist

    route_idx = 0
    while _running:
        now_ms = int(time.time() * 1000)
        lat, lon = _FAKE_ROUTE[route_idx % len(_FAKE_ROUTE)]
        # Add slight jitter so heat cells vary
        lat += random.gauss(0, 0.0003)
        lon += random.gauss(0, 0.0003)

        for key, meta in demo_keys.items():
            if random.random() < 0.4:   # not every key every tick
                rssi = random.gauss(-65, 8)
                ingest_observation(
                    target_key=key,
                    source=meta["source"],
                    ts_ms=now_ms,
                    rssi=rssi,
                    lat=lat,
                    lon=lon,
                    speed_mps=random.uniform(25, 35),   # ~60-80 mph
                    heading=random.uniform(0, 360),
                    meta=meta,
                )

        route_idx += 1
        time.sleep(0.5)   # 2 Hz fake scan


def start_scanning():
    global _running, _thread
    if _running:
        return {"status": "already_running"}
    _running = True
    _thread = threading.Thread(target=_fake_loop, daemon=True)
    _thread.start()
    return {"status": "started"}


def stop_scanning():
    global _running
    _running = False
    flush_all()
    return {"status": "stopped"}


def is_running() -> bool:
    return _running
